# Synthetic Data Notice

This folder contains synthetic legal workflow training/evaluation data.

No real NYSCEF files, real party identities, real case facts, sealed/confidential data, or bulk-collected NYSCEF data were used in this generated synthetic version.

The dataset preserves general procedural workflow structure for private docketing, OCR-routing, eval, and guardrail testing.
